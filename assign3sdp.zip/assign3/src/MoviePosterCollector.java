

// Define the target interface that our Adapter will adhere to
interface MoviePosterCollector {
    String getPoster(String movieTitle);
}
