class OnlineMoviePosterAPI {
    String getPosterFromAPI(String movieTitle) {
        // Simulate fetching a movie poster from an online API
        return "Online Poster for " + movieTitle;
    }
}
