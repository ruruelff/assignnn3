class MoviePosterAdapter implements MoviePosterCollector {
    private LocalMoviePosterDatabase localDatabase;
    private OnlineMoviePosterAPI onlineApi;

    public MoviePosterAdapter(LocalMoviePosterDatabase localDatabase, OnlineMoviePosterAPI onlineApi) {
        this.localDatabase = localDatabase;
        this.onlineApi = onlineApi;
    }

    @Override
    public String getPoster(String movieTitle) {
        // Try to get the poster from the local database
        String localPoster = localDatabase.getPosterFromDatabase(movieTitle);
        if (localPoster != null) {
            return localPoster;
        }

        // If not found in the local database, get it from the online API
        String onlinePoster = onlineApi.getPosterFromAPI(movieTitle);
        if (onlinePoster != null) {
            return onlinePoster;
        }

        return "Poster not found";
    }
}
