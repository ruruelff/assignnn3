import java.util.Scanner;
public class MoviePosterCollectorApp {
    public static void main(String[] args) {
        // Create instances of the Adaptees
        LocalMoviePosterDatabase localDb = new LocalMoviePosterDatabase();
        OnlineMoviePosterAPI onlineApi = new OnlineMoviePosterAPI();

        // Create an instance of the Adapter
        MoviePosterCollector posterCollector = new MoviePosterAdapter(localDb, onlineApi);

        // Accept user input for movie titles
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a movie title: ");
        String movieTitle = scanner.nextLine();
        scanner.close();

        // Collect and display the poster
        String poster = posterCollector.getPoster(movieTitle);
        System.out.println("Collected poster for '" + movieTitle + "': " + poster);
    }
}
